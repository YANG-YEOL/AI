import pandas as pd

df_read = pd.read_csv("003490.csv", encoding='cp949')
df = df_read.iloc[::-1]

x = df[['종가', '거래량']].values
y = df[['종가']].values

for i in range(len(x)):
    for j in range(2):
        x[i][j] = x[i][j].replace(',', '')
        y[i][0] = y[i][0].replace(',', '')

x_shift = x[:][0:-1]
y_shift = y[:][1:]

x_train = x_shift[:419][:]
x_test = x_shift[419:][:]
y_train = x_shift[:419][:]
y_test = x_shift[419:][:]
#test는 train 데이터 비교를 위해 삭제하지 않음

lookback = 5

x_train_sequence = []
y_train_sequence = []

for i in range(len(y_train)-lookback+1):
    x_train_sequence.append(x_train[i:i+lookback])
    y_train_sequence.append(x_train[i+lookback-1])

import numpy as np
x_input = np.array(x_train_sequence)
y_input = np.array(y_train_sequence)

#신경망 구축
from keras.models import Sequential
from keras.layers import Dense, LSTM

model = Sequential()
model.add(LSTM(128, input_shape=(5,2)))
model.add(Dense(1))
model.summary()

model.compile(loss='mse', optimizer='rmsprop', metrics=['acc'])

#100회 반복 학습
h = model.fit(x_input, y_input, epochs=200)

#그래프 출력
import matplotlib.pyplot as plt
plt.plot(h.history[ 'loss'], label='loss')
plt.legend()
plt.title('Loss')

#예측 테스트
lookback = 5

x_test_sequence = []

for i in range(len(y_test)-lookback+1):
    x_test_sequence.append(x_test[i:i+lookback])

x_test_input = np.array(x_test_sequence)

test1 = x_test_input[0].reshape(-1, 5, 2)

pred = model.predict(test1)

print(pred)