import socket
import pickle
import mylib
import base64
import sys
import time

def authentication(IDc, IDtgs):
    if IDc == 'user100' and IDtgs == '10':
    # user_ID와 티켓서버의 번호를 확인
        return True
    else:
        return False

def makeTicket(IDc, addr, IDtgs):
    key = 'kerberos_v2'
    iv = 'AS_Server'

    timestamp = [str(x) for x in time.localtime()[:6]]

    timestamp = ''.join(timestamp)
    lifetime = 3000     # 30분 00초

    ticket = [IDc, addr, IDtgs, timestamp, lifetime]
    # 티켓 = [클라이언트ID, 클라이언트address, 티켓서버번호, 티켓발행시간, 티켓유효기간]

    ticket_pickle = pickle.dumps(ticket)
    # 티켓리스트를 시리얼라이즈
    
    # ticket_pickle += b'\x80'
    
    ticket_pickle = ticket_pickle.decode('utf-8', 'ignore')
    # des3.enc()에서 str타입으로 받으므로 타입변환

    des3 = mylib.MyDES3(key, iv)    # 암호화 하기 위해 객체 생성

    ticket_pickle_des3 = des3.enc(ticket_pickle)
    # 트리플DES로 티켓덤프를 암호화    

    ticket_pickle_des3_base64enc = base64.b64encode(ticket_pickle_des3)
    # 암호화 티켓을 전송하기위해 base64로 인코딩

    return ticket_pickle_des3_base64enc        

def main():
    host = ''
    port = 10100

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # 서버 소켓 = 전송할 주소체계 타입(IPv4, TCP)
    
    server.bind((host, port))
    # 소켓을 포트에 바인딩(매핑) 
    
    print(' [*] AS Server')
    print(' [*] Listening...')
    
    try:
        server.listen(1)    # 접속이 있을때까지 포트열고 대기
        conn, addr = server.accept()
        # 클라이언트와 연결되어 통신가능한 (소켓, 주소)로 반환

        print(' [+] Connect Client')
        print(' [+] addr = {}, port {}'.format(addr[0], addr[1]))
    
        recv_pickle = conn.recv(1024) 
        # 클라이언트가 티켓을 얻기 위한 정보(리스트덤프)

        recv_data = pickle.loads(recv_pickle)
        # 리스트덤프를 디시리얼라이즈
    
        if not authentication(recv_data[0], recv_data[1]):
            conn.close()    # 정보가 일치하지 않으면 연결종료
            print('user_ID or ticket_server do not match!!')
            sys.exit(1)
        
        ticket_pickle_des3_base64enc = makeTicket(recv_data[0], addr[0], recv_data[1])
        # 티켓을 만드는 과정        
    
        conn.send(ticket_pickle_des3_base64enc)
        # 인코딩된 티켓을 클라이언트에게 전송        

        conn.close()    # 클라이언트와 세션종료

    except KeyboardInterrupt:
        print('\b\b [-] '+str(sys.exc_info()[0]).split()[1][1:-2])
        # [Ctrl + c] 등으로 인한 키보드 인터럽트 발생 시 출력        

    finally:
        print('AS_Server end')

if __name__ ==  '__main__':
    main()