import socket
import pickle
import sys

def getTicket_tgs(IDc, IDv):    # (ID, PW, 접속할 서버번호)
    host = '221.164.24.141'    # 접속할 인증서버 IP
    port = 10100                # 접속할 인증서버의 port
    
    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # 클라이언트 소켓 = 전송할 주소체계 타입(IPv4, TCP)    

    conn.connect((host, port))    
    # 소켓으로 연결시도((ip, port))

    send_data = [IDc, IDv]
    send_pickle = pickle.dumps(send_data)
    # 리스트를 전송하기위해 시리얼라이즈

    conn.send(send_pickle)
    # 인증서버로 리스트덤프를 전송

    ticket_tgs = conn.recv(1024)
    # 접속할 티켓서버에 대한 티켓을 받음

    if not ticket_tgs:    # 티켓서버의 티켓을 정상적으로 받지 못한 경우
        print('Not receive a ticket_tgs!!')
        conn.close()
        sys.exit(1)

    conn.close()    # 인증서버와의 세션끊기

    return ticket_tgs

def getTicket_server(IDc, IDv, ticket_tgs):
    host = '221.164.24.141'    # 접속할 티켓서버의 IP
    port = 20100                    # 접속할 티켓서버의 port

    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conn.connect((host, port))
    
    send_data = [IDc, IDv, ticket_tgs]
    # 티켓서버로 전송할 데이터

    send_pickle = pickle.dumps(send_data)
    # 클라이언트의 ID와 티켓이 담긴 리스트를 전송하기위해 시리얼라이즈    
    
    conn.send(send_pickle)
    # 접속할 티켓서버로 리스트덤프를 전송

    ticket_v = conn.recv(1024)
    # 티켓서버로로부터 결과 받기

    if not ticket_v:    # 티켓이 오지 않았다면
        print('Not receive a Ticket_v!!')
        conn.close()
        sys.exit(1)

    conn.close()    # 접속세션과의 세션끊기
    
    return ticket_v

def server_connect(IDc, ticket):
    host = '221.164.24.141'    # 접속할 서비스서버의 IP
    port = 30100                # 접속할 서비스서버의 port

    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conn.connect((host, port))

    send_data = [IDc, ticket]
    # 서비스서버로 전송할 데이터

    send_pickle = pickle.dumps(send_data)
    # 클라이언트의 ID와 티켓이 담긴 리스트를 전송하기위해 시리얼라이즈    
    
    conn.send(send_pickle)
    # 접속할 서버로 리스트덤프를 전송

    recv_pickle = conn.recv(1024)
    # 서버로로부터 결과 받기

    if not recv_pickle:        # 서버로부터 데이터를 받지 못했다면
        print('Data not received!!')
        conn.close()
        sys.exit(1)

    recv_data = pickle.loads(recv_pickle)
    # 덤프를 디시리얼라이즈

    conn.close()     # 접속서버와의 세션끊기

    return recv_data


def main():
    IDc = input('user_ID : ')            # user100
    IDtgs = input('ticket_server : ')     # 10
    # 클라이언트의 ID, 접속할 티켓서버번호 입력

    IDv = input('service_server : ')    # 100
    # 접속할 서비스서버번호 입력

    ticket_tgs = getTicket_tgs(IDc, IDtgs)
    # 클라이언트의 ID, 접속할 티켓서버번호로 티켓서버티켓을 얻는 과정

    ticket_v = getTicket_server(IDc, IDv, ticket_tgs)
    # 클라이언트의 ID, 접속할 서비스서버번호와 티켓서버티켓으로 서비스서버 티켓을 얻는 과정
    
    recv = server_connect(IDc, ticket_v)
    # 클라이언트의 ID와 서비스서버티켓으로 접속시도

    print('recv : {}'.format(recv))
    

if __name__ == '__main__':
    main()