from Crypto.Cipher import DES3
from Crypto.Hash import SHA512

class MyDES3():
    def __init__(self,key,iv='iviv'):
        key = key.encode()        
        iv = iv.encode()
        hash = SHA512.new(key)
        hv = hash.digest()
        self.key = hv[:24]
        hash.update(iv)
        hv = hash.digest()
        self.iv = hv[:8]
        
    def enc(self,msg1): # msg1 is unicode         
        msg,addlen=self.make8stringEx(msg1)
        msg=self.addh(msg,addlen)
        msg = msg.encode()
        des3 = DES3.new(self.key,DES3.MODE_CBC,self.iv)
        return des3.encrypt(msg)
        
    def dec(self,msg1): # msg1 is byte code
        des3 = DES3.new(self.key,DES3.MODE_CBC,self.iv)
        msg = des3.decrypt(msg1)
        msg = self.cutmsg(msg)
        return msg
        
    def cutmsg(self,msg):
        msg = msg.decode('utf-8')
        index= msg.find('#')
        sub = msg[:index]
        nsize = int(sub)
        nmsg=msg[8:len(msg) - nsize]
        return nmsg
        
    def addh(self,msg,size):
        numstr = str(size)
        fsize = 8 - len(numstr)
        fill = '#'*fsize
        numstr.encode()
        nmsg = '123'
        nmsg = numstr + fill  + msg
        return nmsg
    def make8stringEx(self,msg):        
        filler = b''
        mlen = len(msg)
        if mlen % 8 != 0:
            addlen = 8 - mlen % 8
            filler = '0'*addlen
        msg += filler
        return msg,addlen
        
def test():
    pass
    msg = '1234 password'
    des3 = MyDES3('key')
    cmsg= des3.enc(msg)
    print(msg)
    print(cmsg)
    pmsg = des3.dec(cmsg)
    print(pmsg)
    
#test()