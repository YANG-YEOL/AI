import socket
import pickle
import mylib
import base64
import sys
import time
from datetime import datetime

def ticket_verify(ticket_pickle_des3_base64enc):
    key = 'kerberos_v2'
    iv = 'service_server'    
    
    des3 = mylib.MyDES3(key, iv) 

    ticket_pickle_des3 = base64.b64decode(ticket_pickle_des3_base64enc)
    # base64 디코딩 후 저장

    ticket_pickle = des3.dec(ticket_pickle_des3)
    # 트리플 DES3로 복호화 후 저장
    
    ticket_pickle = ticket_pickle.encode()
    # byte타입으로 변환

    ticket_pickle = b'\x80'+ticket_pickle[:-3] + b'\xb8\x0be.' 
    # 트리플 DES3 복호화 시 패딩관련 추가설정

    ticket = pickle.loads(ticket_pickle)
    # 티켓서버에 대한 티켓을 메모리에 로드
    
    return ticket


def authentication(IDc, addr, ticket):
    timestamp = [str(x) for x in time.localtime()[:6]]
    # 현재시간을 속성별로 리스트에 저장
    
    timestamp = int(''.join(timestamp))
    # timestamp를 int형으로 변환

    ticket[3] = int(ticket[3])
    # ticket에 저장된 timestamp도 int형으로 변환

    if IDc == ticket[0] and addr == ticket[1] and '100' == ticket[2] and timestamp - ticket[4] < ticket[3]:
        # ticket = [IDc, addr, IDv, Timestamp, Lifetime]

        # 분기문의 내용은 
        # 현재 서비스서버에 접속한 ID와 티켓에 적힌 ID가 동일한지
        # 현재 서비스서버에 접속한 IP주소와 티켓에 적힌 IP주소가 동일한지
        # 현재 서비스서버의 번호와 티켓에 적혀있는 서버의 번호가 동일한지
        # 티켓의 유효기간이 지나지 않았는지

        return True
    else:
        return False
    
def main():
    host = ''
    port = 30100 

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))

    try:
        print(' [*] Service Server')
        print(' [*] Listening...')
        server.listen(1)    # 접속이 있을때까지 포트열고 대기

        conn, addr = server.accept()
        # 클라이언트와 연결되어 통신가능한 (소켓, 주소)로 반환

        print(' [+] Connect Client')
        print(' [+] addr = {}, port {}'.format(addr[0], addr[1]))
        
        recv_pickle = conn.recv(1024) 
        # [클라이언트ID, 티켓]의 리스트덤프 받기

        recv_data = pickle.loads(recv_pickle)
        # 받은 리스트덤프를 디시리얼라이즈        

        IDc, ticket_pickle_des3_base64enc = recv_data[0], recv_data[1]    
        # 클라이언트ID와 티켓덤프를 암호화 후 인코딩한 정보를 저장

        ticket = ticket_verify(ticket_pickle_des3_base64enc)
        # 티켓을 검증하는 과정

        if not authentication(IDc, addr[0], ticket):
            conn.close()     # 정보가 일치하지 않으면 연결종료
            print('user_ID or address or service_number or ticket_valid_period do not match!!')
            sys.exit(1)

        send_data = [datetime.now().year, datetime.now().month, datetime.now().day]
        # 시간정보를 리스트로 저장

        send_data_pickle = pickle.dumps(send_data)
        conn.send(send_data_pickle)

        conn.close()
    
    except KeyboardInterrupt:
        print('\b\b [-] '+str(sys.exc_info()[0]).split()[1][1:-2])
        # [Ctrl + c] 등으로 인한 키보드 인터럽트 발생 시 출력

    finally:
        print('time_server end')
        # 서버종료 시 출력

if __name__ ==  '__main__':
    main()