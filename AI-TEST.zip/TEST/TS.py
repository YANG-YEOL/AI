import socket
import pickle
import mylib
import base64
import sys
import time

# ticket_server = 10

def ticket_verify(ticket_tgs_pickle_des3_base64enc):
    key = 'kerberos_v2'
    iv = 'AS_Server'    
    
    des3 = mylib.MyDES3(key, iv)

    ticket_tgs_pickle_des3 = base64.b64decode(ticket_tgs_pickle_des3_base64enc)
    # base64 디코딩 후 저장

    ticket_tgs_pickle = des3.dec(ticket_tgs_pickle_des3)
    # 트리플 DES3로 복호화 후 저장
    
    ticket_tgs_pickle = ticket_tgs_pickle.encode()
    # byte타입으로 변환

    ticket_tgs_pickle = b'\x80'+ticket_tgs_pickle[:-3] + b'\xb8\x0be.' 
    # 트리플 DES3 복호화시 패딩관련 추가설정

    ticket_tgs = pickle.loads(ticket_tgs_pickle)
    # 티켓서버에 대한 티켓을 메모리에 로드

    return ticket_tgs

def authentication(IDc, addr, ticket_tgs):
    timestamp = [str(x) for x in time.localtime()[:6]]
    # 현재시간을 속성별로 리스트에 저장

    timestamp = int(''.join(timestamp))
    # timestamp를 int형으로 변환

    ticket_tgs[3] = int(ticket_tgs[3])
    # ticket_tgs에 저장된 timestamp도 int형으로 변환

    if IDc == ticket_tgs[0] and addr == ticket_tgs[1] and '10' == ticket_tgs[2] and timestamp - ticket_tgs[4] < ticket_tgs[3]:
        # ticket_tgs = [IDc, addr, IDtgs, Timestamp, Lifetime]

        # 분기문의 내용은 
        # 현재 티켓서버에 접속한 ID와 티켓에 적힌 ID가 동일한지
        # 현재 티켓서버에 접속한 IP주소와 티켓에 적힌 IP주소가 동일한지
        # 현재 티켓서버의 번호와 티켓에 적혀있는 서버의 번호가 동일한지
        # 티켓의 유효기간이 지나지 않았는지

        return True

    else:
        return False

def makeTicket(IDc, addr, IDv):
    key = 'kerberos_v2'
    iv = 'service_server'
    
    timestamp = [str(x) for x in time.localtime()[:6]]
    # 현재시간을 속성별로 리스트로 저장

    timestamp = ''.join(timestamp)
    lifetime = 3000        # 30분 00초

    ticket = [IDc, addr, IDv, timestamp, lifetime]
    # 티켓 = [클라이언트ID, 클라이언트address, 티켓서버번호, 티켓발행시>간, 티켓유효기간]

    ticket_pickle = pickle.dumps(ticket)
    # 티켓리스트를 시리얼라이즈

    ticket_pickle = ticket_pickle.decode('utf-8', 'ignore')
    # des3.enc()에서 str타입으로 받으므로 타입변환

    des3 = mylib.MyDES3(key, iv)    # 암호화 하기 위해 객체 생성

    ticket_pickle_des3 = des3.enc(ticket_pickle)
    # 트리플DES로 티켓덤프를 암호화 

    ticket_pickle_des3_base64enc = base64.b64encode(ticket_pickle_des3)
    # 암호화 티켓을 전송하기위해 base64로 인코딩

    return ticket_pickle_des3_base64enc


def main():
    host = ''
    port = 20100
    
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))

    print(' [*] Ticket Server')
    print(' [*] Listening...')

    try:
        server.listen(1)    # 접속이 있을때까지 포트열고 대기

        conn, addr = server.accept()
        # 클라이언트와 연결되어 통신가능한 (소켓, 주소)로 반환

        print(' [+] Connect Client')
        print(' [+] addr = {}, port {}'.format(addr[0], addr[1]))
        
        recv_pickle = conn.recv(1024) 
        # [클라이언트ID, 접속할서버번호, 티켓]의 리스트덤프 받기

        recv_data = pickle.loads(recv_pickle)
        # 받은 리스트덤프를 디시리얼라이즈        

        IDc, IDv, ticket_tgs_pickle_des3_base64enc = recv_data[0], recv_data[1], recv_data[2]    
        # 클라이언트ID와 티켓덤프를 암호화후 인코딩한 정보를 저장

        ticket_tgs = ticket_verify(ticket_tgs_pickle_des3_base64enc)
        # 티켓을 검증하는 과정

        if not authentication(IDc, addr[0], ticket_tgs):
            conn.close()     # 정보가 일치하지 않으면 연결종료
            print('user_ID or address or service_number or ticket_valid_period do not match!!')
            sys.exit(1)

        ticket_pickle_des3_base64enc = makeTicket(IDc, addr[0], IDv)
        # 티켓을 만드는 과정 

        conn.send(ticket_pickle_des3_base64enc)
        # 인코딩된 티켓을 클라이언트에게 전송

        conn.close()    # 클라이언트와 세선종료
    
    except KeyboardInterrupt:
        print('\b\b [-] '+str(sys.exc_info()[0]).split()[1][1:-2])
        # [Ctrl + c] 등으로 인한 키보드 인터럽트 발생 시 출력

    finally:
        print('ticket_server end')
        # 서버종료 시 출력

if __name__ ==  '__main__':
    main()